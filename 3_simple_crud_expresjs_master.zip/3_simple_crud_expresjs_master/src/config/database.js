var sqlite3 = require('sqlite3').verbose()

let db = new sqlite3.Database(process.env.DBSOURCE, (err) => {
    if (err) {
      // Cannot open database
      console.error(err.message)
      throw err
    }else{
        console.log('Connected to the SQLite database.')
        db.run(`CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name text, 
            emails text UNIQUE, 
            age text, 
            bod text
            )`,
        (err) => {
            if (err) {
                // Table already created
            }else{
                // Table just created, creating some rows
                var insert = 'INSERT INTO users (name, emails, age, bod) VALUES (?,?,?,?)'
                db.run(insert, ["admin","admin@example.com","20","2005-10-10"])
                db.run(insert, ["user","user@example.com","30","1995-01-01"])
            }
        });  
    }
});


module.exports = db