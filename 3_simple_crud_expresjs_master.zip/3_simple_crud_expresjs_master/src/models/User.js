class User {
    constructor(id, name, email, age, bod) {
        this.id = id;
        this.name = name;
        this.emails = email;
        this.age = age;
        this.bod = bod;
    }
}

module.exports = User;
