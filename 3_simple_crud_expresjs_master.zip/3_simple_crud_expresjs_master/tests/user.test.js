const {UserService} = require('../src/services');
const {UserRepositories} = require('../src/repositories');

describe('UserService', () => {
    beforeEach(() => {
        UserRepositories.users = [];
    });

    
});
