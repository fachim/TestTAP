# Menemukan dan Perbaiki Issue dari aplikasi ini 

## Aplikasi CRUD ini tidak terhubung ke database, dibuatkan database dan mengikuti CSR Pattern dibuatkan query atau ORM dibagian Repositury
Database: SQLite dengan koneksi nya juga inisialisasi, disimpan di file db.sqlite, .env untuk kebutuhan konfigurasi lokal sudah dibuatkan 

## Instalasi dan menjalankan app
Sesuai petunjuk diawal, ke folder ./src/client lalu ketik `pnpm install` dan `pnpm build` (untuk build front-end). kemudian kembali ke folder utama ./src lalu ketik `pnpm install` dan `pnpm start` (untuk menjalankan semua, back-end dan front-end melalui index.js).
