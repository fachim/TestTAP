# Pertanyaan Kondisi dan Issue

## Detail
Jika dalam 1 projek terdapat 3 branch pada repository

Development : terdapat penambahan fitur A
QA : sedang testing fitur B
Production : ditemukan issue yang harus diperbaiki saat itu juga
Jelaskan apa yang harus dilakukan supaya issue dapat diperbaiki serta branch QA & Development tidak terjadi conflict dan tetap up-to-date terhadap perbaikan issue?

## Jawaban
Berikut solusi yang bisa dilakukan: 

Kita buat branch dari Production, misalnya fix-abcd. Push perbaikan di branch tersebut, setelah dilakukan test, merge hasil perbaikan di branch fix-abcd ke Production. Merge hasil perbaikan ke QA dan Development, jadi perbaikan tidak hilang ketika nanti QA atau Development berpindah ke Production.  