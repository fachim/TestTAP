import React, { useState, useEffect } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement, 
  LineElement,  
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

import { Line } from 'react-chartjs-2'; 

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const Chartjs = () => {
  const [chartData, setChartData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Tahun 2024 dan sebelumnya',
        font: {
          size: 18,
        },
      },
    },
    scales: {
      y: {
        ticks: {
          callback: function(value, index, values) {
            return (value / 1000000) + ' Juta Orang';
          }
        }
      }
    }
  };


  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const apiUrl = 'https://api.worldbank.org/v2/country/ID/indicator/SP.POP.TOTL?format=json';
        const response = await fetch(apiUrl);
        const result = await response.json();

        if (result && result[1]) {
          const filteredData = result[1]
            .filter(item => item.value !== null && parseInt(item.date) >= 2014);
          
          const reversedData = filteredData.reverse();

          const processedData = {
            labels: reversedData.map(item => item.date), 
            datasets: [
              {
                label: 'Total',
                data: reversedData.map(item => item.value), 
                borderColor: 'rgba(151, 99, 255, 1)',
                backgroundColor: 'rgba(159, 99, 255, 0.5)',
              },
            ],
          };
          setChartData(processedData);
        }

      } catch (error) {
        console.error("Gagal ambil data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);

  if (isLoading) {
    return (
      <div className="card shadow-sm text-center p-5">
        <p>Ambil data...</p>
        <div className="spinner-border text-danger" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (!chartData) {
    return <div className="card shadow-sm text-center p-5"><p>Gagal ambil data.</p></div>;
  }
  
  return (
    <div className="card shadow-sm">
      <div className="card-body">
        <Line options={options} data={chartData} />
      </div>
    </div>
  );
};

export default Chartjs;