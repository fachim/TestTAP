import Chartjs from './components/Chartjs';

function App() {
  return (
    <div className="container mt-5">
      <div className="row justify-content-center align-items-center min-vh-100">
        <div className="col-lg-12 col-md-12"> 
          <header className="text-center mb-4">
            <h1 className="display-5 fw-bold">Grafik Penduduk Indonesia 2024</h1>
            <p className="lead">10 Tahun Terakhir Dari World Bank</p>
          </header>
          
          <main>
            <Chartjs />
          </main>
        </div>
      </div>
    </div>
  );
}

export default App;