# Grafik Penduduk Indonesia 2024 dan data sebelumnya 

## Dibuat Dari Template React + Vite, react-chartjs-2 dan Bootstrap
Component: Chartjs.jsx yang mengambil data dari API World Bank

## Instalasi dan menjalankan app
Install: `npm install` 
Jalankan `npm run dev`
