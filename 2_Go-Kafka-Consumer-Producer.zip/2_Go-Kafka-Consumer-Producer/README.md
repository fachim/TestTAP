# Go Kafka Consumer Producer 
Hasil pembelajaran dari https://github.com/sohamkamani/golang-kafka-example 

## Pastikan Kafka hasil download, instance atau container terinstall
cara install Kafka bisa dicek disini, hasil build di java atau docker: https://kafka.apache.org/quickstart
dan rubah `brokerAddress` di code main.go sesuai address/url Kafka instance

## Instalasi dan menjalankan app
install: `go mod tidy && go mod vendor`
jalankan: `go run main.go`

